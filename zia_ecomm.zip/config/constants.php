<?php

return [
    'SITE_NAME' => 'ZIA ECOM'
]

?>